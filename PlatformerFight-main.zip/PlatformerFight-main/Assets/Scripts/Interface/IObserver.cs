public interface IObserver
{
    void Notify();
}
