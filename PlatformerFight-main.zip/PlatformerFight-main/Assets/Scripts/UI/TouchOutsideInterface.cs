public interface TouchOutsideInterface
{
    void TouchOutside();
}
