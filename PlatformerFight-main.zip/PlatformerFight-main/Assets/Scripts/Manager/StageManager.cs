using Cinemachine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StageManager : MonoBehaviour
{
    public string stageName;

    public CinemachineVirtualCamera stageCamera;

    public Checkpoint checkPoint;
}
